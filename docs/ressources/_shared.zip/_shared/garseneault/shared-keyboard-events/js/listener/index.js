let robot = require("robotjs");
let { Server } = require('node-osc');
robot.setKeyboardDelay(0);

let oscServer = new Server(50320, '0.0.0.0');
console.log('keyserver @port 50320');
oscServer.on('message', function (msg) 
{ 
console.log(msg);
  if (msg[0]=="/keyToggle")
  {
    let state; 
    if (msg[2]=="1"){state="down";} else{state="up";} 
    robot.keyToggle(msg[1], state);
  }
  if (msg[0]=="/key")
  { 
    robot.keyTap(msg[1]);
  }
});


