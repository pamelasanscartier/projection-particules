import keyboard
import fileinput
import json
import sys
import datetime

for line in fileinput.input():
	line = line
	line = line[:-1]
	print(line, " ", print(datetime.datetime.now()))
	try:
		keyboard.send(line)
	except:
		print("unsuported caracter")
